import { TdImageProps } from './type';
export declare type ImageProps = TdImageProps;
export * from './props';
export * from './image';

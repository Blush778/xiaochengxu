const props = {
    offset: {
        type: null,
    },
    span: {
        type: null,
    },
};
export default props;

import { TdButtonProps } from './type';
declare const props: TdButtonProps;
export default props;

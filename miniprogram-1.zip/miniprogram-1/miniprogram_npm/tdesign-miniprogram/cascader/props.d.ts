import { TdCascaderProps } from './type';
declare const props: TdCascaderProps;
export default props;

import { TdEmptyProps } from './type';
declare const props: TdEmptyProps;
export default props;

import { TdDrawerProps } from './type';
declare const props: TdDrawerProps;
export default props;

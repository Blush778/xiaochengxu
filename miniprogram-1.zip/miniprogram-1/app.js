App({
  globalData: {
    cartItems: [], // 购物车数据
  },

  // 更新购物车 TabBar 角标
  updateCartBadge() {
    const cartCount = this.globalData.cartItems.reduce((sum, item) => sum + item.quantity, 0);
    if (cartCount > 0) {
      wx.setTabBarBadge({
        index: 3, // 购物车Tab的索引（你的 `app.json` 里是第 3 个）
        text: String(cartCount),
      });
    } else {
      wx.removeTabBarBadge({ index: 3 });
    }
  }
});
